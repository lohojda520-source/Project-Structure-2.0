# =====================================================
# SmartAdminBot PRO
# Database Module
# SQLite3
# =====================================================

import sqlite3
from datetime import datetime

DB_NAME = "users.db"


# =====================================================
# INIT DATABASE
# =====================================================

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            joined_at TEXT
        )
    """)

    conn.commit()
    conn.close()


# =====================================================
# ADD USER
# =====================================================

def add_user(user_id: int):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("SELECT id FROM users WHERE id = ?", (user_id,))
    exists = cursor.fetchone()

    if not exists:
        cursor.execute(
            "INSERT INTO users (id, joined_at) VALUES (?, ?)",
            (user_id, datetime.now().isoformat())
        )
        conn.commit()

    conn.close()


# =====================================================
# GET USERS COUNT
# =====================================================

def get_users_count():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM users")
    count = cursor.fetchone()[0]

    conn.close()
    return count


# =====================================================
# SmartAdminBot PRO
# Database Module (Production Version)
# =====================================================

import sqlite3
from datetime import datetime
from config import DATABASE_NAME


def get_connection():
    return sqlite3.connect(DATABASE_NAME)


def init_db(db_name: str):
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            joined_at TEXT
        )
    """)

    conn.commit()
    conn.close()


def add_user(user_id: int):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "INSERT OR IGNORE INTO users (user_id, joined_at) VALUES (?, ?)",
        (user_id, datetime.now().isoformat())
    )

    conn.commit()
    conn.close()


def get_users_count() -> int:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM users")
    count = cursor.fetchone()[0]

    conn.close()
    return count


def get_all_users():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT user_id FROM users")
    users = cursor.fetchall()

    conn.close()
    return users


def clear_all_users():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM users")

    conn.commit()
    conn.close()