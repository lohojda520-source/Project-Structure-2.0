# =====================================================
# SmartAdminBot PRO
# FINAL MAIN (aiogram 3.7+)
# =====================================================

import asyncio
import logging
from datetime import datetime

from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

from config import (
    BOT_TOKEN,
    ADMINS,
    PRODUCT_NAME,
    VERSION,
    SHOW_STARTUP_LOG,
    ENABLE_BROADCAST,
    ENABLE_USER_CLEAR,
    DATABASE_NAME,
    BROADCAST_DELAY,
    LOG_ERRORS,
)

from database import (
    init_db,
    add_user,
    get_users_count,
    get_all_users,
    clear_all_users,
)

from keyboards import (
    admin_keyboard,
    confirm_clear_keyboard,
    broadcast_cancel_keyboard,
)

# =====================================================
# LOGGING
# =====================================================

if LOG_ERRORS:
    logging.basicConfig(
        level=logging.INFO,
        filename="bot.log",
        format="%(asctime)s - %(levelname)s - %(message)s",
    )

# =====================================================
# GLOBALS
# =====================================================

START_TIME = datetime.now()
broadcast_mode = False

bot = Bot(
    token=BOT_TOKEN,
    default=DefaultBotProperties(parse_mode=ParseMode.HTML)
)

dp = Dispatcher()

# =====================================================
# UTILS
# =====================================================

def is_admin(user_id: int) -> bool:
    return user_id in ADMINS


# =====================================================
# START
# =====================================================

@dp.message(Command("start"))
async def cmd_start(message: Message):
    add_user(message.from_user.id)

    await message.answer(
        f"🚀 <b>{PRODUCT_NAME} {VERSION}</b>\n\n"
        "Status: Active\n"
        "You are successfully registered."
    )


# =====================================================
# ADMIN PANEL
# =====================================================

@dp.message(Command("admin"))
async def cmd_admin(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("⛔ Access denied.")
        return

    await message.answer(
        f"🔐 <b>{PRODUCT_NAME} | Admin Panel</b>\n"
        f"Version: {VERSION}\n\n"
        "Choose an action:",
        reply_markup=admin_keyboard(),
    )


# =====================================================
# STATS
# =====================================================

@dp.callback_query(F.data == "stats")
async def stats_handler(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return

    users = get_users_count()
    uptime = datetime.now() - START_TIME

    await callback.message.edit_text(
        "📊 <b>Statistics</b>\n\n"
        f"Users: {users}\n"
        f"Uptime: {str(uptime).split('.')[0]}\n"
        f"Version: {VERSION}",
        reply_markup=admin_keyboard(),
    )


# =====================================================
# USERS
# =====================================================

@dp.callback_query(F.data == "users")
async def users_handler(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return

    users = get_users_count()

    await callback.message.edit_text(
        f"👥 <b>Total users:</b> {users}",
        reply_markup=admin_keyboard(),
    )


# =====================================================
# BROADCAST START
# =====================================================

@dp.callback_query(F.data == "broadcast")
async def broadcast_start(callback: CallbackQuery):
    global broadcast_mode

    if not ENABLE_BROADCAST:
        await callback.answer("Broadcast disabled.", show_alert=True)
        return

    if not is_admin(callback.from_user.id):
        return

    broadcast_mode = True

    await callback.message.answer(
        "📢 Send the message to broadcast to all users.",
        reply_markup=broadcast_cancel_keyboard(),
    )


# =====================================================
# CANCEL BROADCAST
# =====================================================

@dp.callback_query(F.data == "cancel_broadcast")
async def cancel_broadcast(callback: CallbackQuery):
    global broadcast_mode

    if not is_admin(callback.from_user.id):
        return

    broadcast_mode = False

    await callback.message.edit_text(
        "❌ Broadcast cancelled.",
        reply_markup=admin_keyboard(),
    )


# =====================================================
# HANDLE BROADCAST MESSAGE
# =====================================================

@dp.message()
async def handle_broadcast(message: Message):
    global broadcast_mode

    if not is_admin(message.from_user.id):
        return

    if not broadcast_mode:
        return

    users = get_all_users()
    sent = 0

    for user in users:
        user_id = user[0]

        try:
            await bot.send_message(user_id, message.text)
            sent += 1
            await asyncio.sleep(BROADCAST_DELAY)
        except Exception as e:
            if LOG_ERRORS:
                logging.error(f"Broadcast error to {user_id}: {e}")

    broadcast_mode = False

    await message.answer(
        f"✅ Broadcast sent to {sent} users.",
        reply_markup=admin_keyboard(),
    )


# =====================================================
# CLEAR USERS CONFIRM
# =====================================================

@dp.callback_query(F.data == "clear_users_confirm")
async def clear_users_confirm(callback: CallbackQuery):
    if not ENABLE_USER_CLEAR:
        await callback.answer("Clear users disabled.", show_alert=True)
        return

    if not is_admin(callback.from_user.id):
        return

    await callback.message.edit_text(
        "⚠️ Are you sure you want to delete ALL users?",
        reply_markup=confirm_clear_keyboard(),
    )


# =====================================================
# CLEAR USERS
# =====================================================

@dp.callback_query(F.data == "clear_users")
async def clear_users_handler(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return

    clear_all_users()

    await callback.message.edit_text(
        "🧹 All users deleted.",
        reply_markup=admin_keyboard(),
    )


# =====================================================
# BACK
# =====================================================

@dp.callback_query(F.data == "back_to_admin")
async def back_handler(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return

    await callback.message.edit_text(
        "🔐 Admin Panel",
        reply_markup=admin_keyboard(),
    )


# =====================================================
# CLOSE
# =====================================================

@dp.callback_query(F.data == "close")
async def close_handler(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return

    await callback.message.delete()


# =====================================================
# MAIN
# =====================================================

async def main():
    init_db(DATABASE_NAME)

    if SHOW_STARTUP_LOG:
        print("=================================")
        print(f"{PRODUCT_NAME} {VERSION}")
        print("Status: RUNNING")
        print("Mode: PRO")
        print("=================================")

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())