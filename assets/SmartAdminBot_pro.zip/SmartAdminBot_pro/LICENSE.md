\# SmartAdminBot PRO - Commercial License



Copyright (c) 2026



All rights reserved.



---



\## 1. License Grant



Upon purchasing SmartAdminBot PRO, the buyer is granted a non-exclusive, non-transferable license to:



\- Use the software for personal or commercial projects

\- Install the software for clients

\- Modify the source code for internal or client use

\- Use the software on multiple projects owned by the buyer



---



\## 2. Restrictions



The buyer is NOT allowed to:



\- Resell the source code as a standalone product

\- Redistribute the source code publicly

\- Upload the source code to public repositories

\- Claim authorship of the original software

\- Share the source code with third parties who did not purchase a license



Reselling modified versions of the software as a competing product is strictly prohibited.



---



\## 3. Ownership



The software remains the intellectual property of the original developer.



Purchasing this product grants usage rights only, not ownership of the source code.



---



\## 4. Liability



The software is provided "as is", without warranty of any kind.



The developer shall not be held liable for:

\- Data loss

\- Financial loss

\- Service interruptions

\- Misuse of the software



---



\## 5. Termination



Violation of this license will result in immediate termination of usage rights.



---



\## 6. Support



Support is provided only if explicitly included in the purchase package.



---



SmartAdminBot PRO  

Commercial Automation Software  

Version 2.0

