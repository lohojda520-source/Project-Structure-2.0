# =====================================================
# SmartAdminBot PRO
# Keyboards Module
# =====================================================

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


# =====================================================
# MAIN ADMIN KEYBOARD
# =====================================================

def admin_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📊 Statistics",
                    callback_data="stats"
                ),
                InlineKeyboardButton(
                    text="👥 Users",
                    callback_data="users"
                ),
            ],
            [
                InlineKeyboardButton(
                    text="📢 Broadcast",
                    callback_data="broadcast"
                ),
                InlineKeyboardButton(
                    text="⚙ Settings",
                    callback_data="settings"
                ),
            ],
            [
                InlineKeyboardButton(
                    text="🧹 Clear Users",
                    callback_data="clear_users_confirm"
                ),
            ],
            [
                InlineKeyboardButton(
                    text="❌ Close",
                    callback_data="close"
                ),
            ],
        ]
    )


# =====================================================
# CLEAR USERS CONFIRMATION
# =====================================================

def confirm_clear_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Confirm",
                    callback_data="clear_users"
                ),
                InlineKeyboardButton(
                    text="⬅ Back",
                    callback_data="back_to_admin"
                ),
            ]
        ]
    )


# =====================================================
# BROADCAST CANCEL KEYBOARD
# =====================================================

def broadcast_cancel_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="❌ Cancel Broadcast",
                    callback_data="cancel_broadcast"
                )
            ]
        ]
    )


# =====================================================
# BACK BUTTON
# =====================================================

def back_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="⬅ Back",
                    callback_data="back_to_admin"
                )
            ]
        ]
    )