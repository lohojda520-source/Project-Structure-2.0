# =====================================================
# SmartAdminBot PRO
# Configuration File
# =====================================================

# =========================
# 🔐 TELEGRAM SETTINGS
# =========================

BOT_TOKEN = "PASTE_YOUR_BOT_TOKEN_HERE"

ADMINS = [
    123456789
]

# =========================
# 📦 PRODUCT INFO
# =========================

PRODUCT_NAME = "SmartAdminBot PRO"
VERSION = "v2.0"

# =========================
# ⚙ SYSTEM SETTINGS
# =========================

SHOW_STARTUP_LOG = True
ENABLE_BROADCAST = True
ENABLE_USER_CLEAR = True

# =========================
# 💾 DATABASE
# =========================

DATABASE_NAME = "users.db"

# =========================
# 📢 BROADCAST
# =========================

BROADCAST_DELAY = 0.05

# =========================
# 🛡 LOGGING
# =========================

LOG_ERRORS = True