python main.py
pause