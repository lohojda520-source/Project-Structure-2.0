from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def admin_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📊 Статистика", callback_data="stats")],
            [InlineKeyboardButton(text="📢 Розсилка", callback_data="broadcast")],
            [InlineKeyboardButton(text="👥 Користувачі", callback_data="users")],
            [InlineKeyboardButton(text="⚙ Налаштування", callback_data="settings")],
            [InlineKeyboardButton(text="🔙 Закрити", callback_data="close")]
        ]
    )