from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def admin_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📊 Statistics", callback_data="stats")],
            [InlineKeyboardButton(text="📢 Broadcast", callback_data="broadcast")],
            [InlineKeyboardButton(text="👥 Users", callback_data="users")],
            [InlineKeyboardButton(text="⚙ Settings", callback_data="settings")],
            [InlineKeyboardButton(text="🔙 Close", callback_data="close")]
        ]
    )